﻿using CurrencyExchangeManager.Models;
using CurrencyExchangeManager.Services;
using Microsoft.AspNetCore.Mvc;
//using YourNamespace.ICurrExchaService;

namespace CurrencyExchangeManager.Controllers
{
    public class CurrencyExchange_Controller
    {
    }
   

[ApiController]
    [Route("api/[controller]")]
    public class CurrencyExchangeController : ControllerBase
    {
        private readonly ICurrExchaService _currencyExchangeService;
        private readonly IRepository _repository;

        public CurrencyExchangeController(ICurrExchaService currencyExchangeService, IRepository repository)
        {
            _currencyExchangeService = currencyExchangeService;
            _repository = repository;
        }

        [HttpGet("convert")]
        public async Task<ActionResult<ConversionResult>> ConvertCurrency(string baseCurrency, string targetCurrency, decimal amount)
        {
            try
            {
                var result = await _currencyExchangeService.ConvertCurrencyAsync(baseCurrency, targetCurrency, amount);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }

        [HttpGet("history")]
        public async Task<ActionResult<IEnumerable<CurrencyRate>>> GetConversionHistory()
        {
            try
            {
                var history = await _repository.GetConversionHistory();
                return Ok(history);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
    }
}
