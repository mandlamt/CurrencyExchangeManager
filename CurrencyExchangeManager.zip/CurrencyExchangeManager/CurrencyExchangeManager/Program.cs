using CurrencyExchangeManager.Data;
using CurrencyExchangeManager.Services;



//using Microsoft.EntityFrameworkCore;
//using StackExchange.Redis;
//using Microsoft.EntityFrameworkCore;
//using MySql.Data.EntityFrameworkCore.Extensions; // Add this line

//using Microsoft.Data.EntityFrameworkCore.Extensions; // Add this line


internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddControllers();
        builder.Services.AddEndpointsApiExplorer();

        var app = builder.Build();
        app.UseRouting();
        app.UseOutputCache();

       

        // Add services to the container.

        builder.Services.AddControllers();

        builder.Services.AddEndpointsApiExplorer();
      //  builder.Services.AddSwaggerGen();

       

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            //app.UseSwagger();
            //app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseAuthorization();

        app.MapControllers();

        app.Run();




        //services.AddSwaggerGen(c =>
        //{
        //    c.SwaggerDoc("v1", new Info { Title = "My API", Version = "v1" });
        //    // Add any other configuration you need
        //});











        //object value = builder.Services.AddSwaggerGen();



        // Configure MySQL
        //var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
        //builder.Services.AddDbContext<AppDbContext>(options =>
        //    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

        // Configure Redis
        //builder.Services.AddSingleton<IConnectionMultiplexer>(ConnectionMultiplexer.Connect(builder.Configuration.GetConnectionString("Redis")));

        // Register services
        //builder.Services.AddScoped<ICurrencyExchangeService, CurrencyExchangeService>();
        //builder.Services.AddScoped<ICacheService, RedisCacheService>();
        //builder.Services.AddScoped<IRepository, MySqlRepository>();

      //  var app = builder.Build();

        // Configure the HTTP request pipeline.
        //if (app.Environment.IsDevelopment())
        //{
        //    app.UseSwagger();
        //    app.UseSwaggerUI();
        //}

        app.UseHttpsRedirection();
        app.UseAuthorization();
        app.MapControllers();

        app.Run();
    }
}