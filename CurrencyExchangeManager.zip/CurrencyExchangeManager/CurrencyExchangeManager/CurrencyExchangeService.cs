﻿//public class CurrencyExchangeServiceTests
//{
//}


namespace CurrencyExchangeManager
{
    internal class CurrencyExchangeService
    {
        private object object1;
        private object object2;
        private object object3;

        public CurrencyExchangeService(object object1, object object2, object object3)
        {
            this.object1 = object1;
            this.object2 = object2;
            this.object3 = object3;
        }

        internal async Task ConvertCurrencyAsync(string v1, string v2, int v3)
        {
            throw new NotImplementedException();
        }
    }
}