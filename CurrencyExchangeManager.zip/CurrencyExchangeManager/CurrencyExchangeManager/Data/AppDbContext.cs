﻿using CurrencyExchangeManager.Models;
using System.Data.SqlTypes;
//using System.Data.Entity;



namespace CurrencyExchangeManager.Data
{
    public record AppDbContext(DbSet<CurrencyRate> CurrencyRates) : object()
    {
        private static object options;
    }
}
