﻿namespace CurrencyExchangeManager.Data
{
    internal class DbContextOptions<T>
    {
    }
}