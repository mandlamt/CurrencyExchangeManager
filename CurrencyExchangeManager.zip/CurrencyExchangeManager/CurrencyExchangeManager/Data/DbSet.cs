﻿namespace CurrencyExchangeManager.Data
{
    public class DbSet<T>
    {
    }
}