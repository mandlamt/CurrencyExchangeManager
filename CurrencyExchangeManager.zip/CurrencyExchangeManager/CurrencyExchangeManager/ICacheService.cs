﻿//public class CurrencyExchangeServiceTests
//{
//}

namespace CurrencyExchangeManager
{
    internal interface ICacheService
    {
    }
}