﻿//public class CurrencyExchangeServiceTests
//{
//}

//using Xunit;
//using Moq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CurrencyExchangeManager.Services;

namespace CurrencyExchangeManager
{
    public class CurrencyExchangeServiceTests
    {
        private object Assert;

        public object It { get; private set; }

        //[Fact]
        public async Task ConvertCurrencyAsync_ShouldReturnCorrectResult()
        {
            // Arrange
            var mockConfiguration = new Mock<IConfiguration>();
            var mockCacheService = new Mock<ICacheService>();
            var mockRepository = new Mock<IRepository>();

            //mockCacheService.Setup(c =>
            //{                                     
            //    return c.GetAsync<decimal>(It.IsAny<string>());
            //}).ReturnsAsync(1.2m);

            //var service = new CurrencyExchangeService(mockConfiguration.Object, mockCacheService.Object, mockRepository.Object);

            // Act
            //var result = await service.ConvertCurrencyAsync("USD",
            //                                                "EUR",
            //                                                100);

            //// Assert
            //Assert.Equals("USD", result.BaseCurrency);
            //Assert.Equals("EUR", result.TargetCurrency);
            //Assert.Equals(100, result.Amount);
            //Assert.Equals(120, result.ConvertedAmount);
            //Assert.Equals(1.2m, result.Rate);
        }
    }
}
