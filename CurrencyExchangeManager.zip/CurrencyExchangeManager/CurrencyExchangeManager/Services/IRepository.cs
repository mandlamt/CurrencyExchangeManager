﻿using CurrencyExchangeManager.Models;

namespace CurrencyExchangeManager.Services
{
    public interface IRepository
    {
  
        Task AddCurrencyRateAsyncs(CurrencyRate rate);
        Task AddCurrencyRateAsync(CurrencyRate currencyRate);
        Task<IEnumerable<CurrencyRate>> GetConversionHistory();
    }
}
