﻿using CurrencyExchangeManager.Data;
using CurrencyExchangeManager.Models;

namespace CurrencyExchangeManager.Services
{
    //public class MySql_Repository
    //{
    //}



    public class MySql_Repository //: IRepository
    {
        private readonly AppDbContext _context;

        //public MySql_Repository(AppDbContext context) => _context = context;

        //Task AddCurrencyRateAsyncs(CurrencyRate rate);
        //Task AddCurrencyRateAsync(CurrencyRate currencyRate);
        //Task<IEnumerable<CurrencyRate>> GetConversionHistoryAsync();

        public async Task AddCurrencyRateAsyncs(CurrencyRate rate)
        {
            //object value = _context.CurrencyRates.Add(rate);
            //await _context.SaveChangesAsync();
        }
        public async Task AddCurrencyRateAsync(CurrencyRate rate)
        {
            //_context.CurrencyRates.Add(rate);
            //await _context.SaveChangesAsync();
        }

        //public IEnumerable<CurrencyRate> ConversionHistory
        //{
        //    get
        //    {
        //        return 0;// await _context.CurrencyRates.OrderByDescending(r => r.dtTimestamp).Take(100).ToListAsync();
        //    }
        //}
    }
}
