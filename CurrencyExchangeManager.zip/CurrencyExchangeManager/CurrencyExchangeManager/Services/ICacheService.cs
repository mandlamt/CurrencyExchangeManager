﻿namespace CurrencyExchangeManager.Services
{
    public interface ICache_Service
    {
   
        Task<T> GetAsync<T>(string _key);
        Task SetAsync<T>(string _key, T _value, TimeSpan _expiration);
        Task SetAsync(string cacheKey, object rate, TimeSpan timeSpan);
    }
}
