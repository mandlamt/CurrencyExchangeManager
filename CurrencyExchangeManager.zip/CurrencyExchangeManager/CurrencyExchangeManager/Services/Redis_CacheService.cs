﻿namespace CurrencyExchangeManager.Services
{
    public class RedisCacheService(IConnectionMultiplexer redis) //: ICache_Service
    {
        public object JsonConvert { get; private set; }

        //public async Task<T> GetAsync<T>(string key)
        //{
        //    var db = redis.GetDatabase();
        //    //var value = await db.StringGetAsync(key);
        //    //return !value.HasValue ? default : JsonConvert.DeserializeObject<T>(value);
        //    return;
        //}

        public async Task SetAsync<T>(string key, T value, TimeSpan expiration)
        {
            var db = redis.GetDatabase();
            //object value1 = await db.StringSetAsync(
            //    key,
            //    JsonConvert.SerializeObject(value),
            //    expiration);
        }
    }
}
