﻿using CurrencyExchangeManager.Models;

namespace CurrencyExchangeManager.Services
{
    public interface ICurrExchaService
    {
   
        Task<decimal> GetExchRateAsync(string baseCurrency, string targetCurrency);
        Task<ConversionResult> ConvertCurrencyAsync(string baseCurrency, string targetCurrency, decimal amount);

       // Task<decimal> ConvertCurrencyAsync(string baseCurrency, string targetCurrency, decimal amount);
    }
}
