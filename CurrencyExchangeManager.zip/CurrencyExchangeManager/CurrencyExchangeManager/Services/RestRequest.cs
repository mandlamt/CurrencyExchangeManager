﻿namespace CurrencyExchangeManager.Services
{
    internal class RestRequest
    {
        private object value;

        public RestRequest(object value) => this.value = value;
    }
}