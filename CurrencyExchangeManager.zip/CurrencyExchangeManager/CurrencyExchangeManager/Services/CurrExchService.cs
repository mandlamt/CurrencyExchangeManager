﻿using CurrencyExchangeManager.Models;
//using Microsoft.Extensions.Configuration.Binder;


// Install-Package Microsoft.Extensions.Configuration.Binder
namespace CurrencyExchangeManager.Services
{
    public class CurrExchService
    {

        private readonly IConfiguration _configuration;
        private readonly ICache_Service _cacheService;
        private readonly IRepository _repository;
        private object rate;

        public object Method { get; private set; }
        public object JObject { get; private set; }

        public CurrExchService(IConfiguration configuration, ICache_Service cache_Service, IRepository repository_)
        {
            _configuration = configuration;
            _cacheService = cache_Service;
            _repository = repository_;
        }

        public async Task<decimal> GetExchangeRateAsync(string baseCurrency, string targetCurrency)
        {
            string cacheKey = $"rate:{baseCurrency}:{targetCurrency}";
            var cachedRate = await _cacheService.GetAsync<decimal>(cacheKey);

            if (cachedRate != default)
            {
                return cachedRate;
            }

            var apiKey = _configuration["ExchangeRateApi:ApiKey"];
            var client = new RestClient($"https://api.exchangerate-api.com/v4/latest/{baseCurrency}");
            var request = new RestRequest(value: Method.ToString);
            var response = "";// await client.ExecuteAsync(request);

            if (response !="")//.IsSuccessful)
            {
              //  var data = JObject.Parse(response.Content);
              //  var rate = data["rates"][targetCurrency].Value<decimal>();

                await _cacheService.SetAsync(cacheKey, rate, TimeSpan.FromMinutes(15));
                await _repository.AddCurrencyRateAsyncs(new CurrencyRate
                {
                    sBaseCurrency = baseCurrency,
                    sTargetCurrency = targetCurrency,
                    dRate = (decimal)rate,
                    dtTimestamp = DateTime.UtcNow
                });

                return (decimal)rate;
            }

            throw new Exception("Failed to fetch exchange rates");
        }

        public async Task<ConversionResult> ConvertCurrencyAsync(string baseCurrency, string targetCurrency, decimal amount)
        {
            var rate = await GetExchangeRateAsync(baseCurrency, targetCurrency);
            var convertedAmount = amount * rate;

            return new ConversionResult
            {
                sBaseCurrency = baseCurrency,
                sTargetCurrency = targetCurrency,
                dAmount = amount,
                dConvertedAmount = convertedAmount,
                dRate = rate,
                dTimestamp = DateTime.UtcNow
            };
        }
    }
}
