﻿namespace CurrencyExchangeManager.Services
{
    internal interface IConnectionMultiplexer
    {
        object GetDatabase();
    }
}