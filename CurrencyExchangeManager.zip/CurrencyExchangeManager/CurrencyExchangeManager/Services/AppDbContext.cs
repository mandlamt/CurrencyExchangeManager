﻿namespace CurrencyExchangeManager.Services
{
    internal class AppDbContext
    {
        public object CurrencyRates { get; internal set; }
    }
}