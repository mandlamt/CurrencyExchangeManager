﻿namespace CurrencyExchangeManager.Models
{
    public class CurrencyRate
    {
            public int Id { get; set; }
            public string sBaseCurrency { get; set; }
            public string sTargetCurrency { get; set; }
            public decimal dRate { get; set; }
            public DateTime dtTimestamp { get; set; }
        
    }
}
