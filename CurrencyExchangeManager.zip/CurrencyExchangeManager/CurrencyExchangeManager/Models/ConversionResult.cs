﻿namespace CurrencyExchangeManager.Models
{
    public class ConversionResult
    {
        public string sBaseCurrency { get; set; }
        public string sTargetCurrency { get; set; }
        public decimal dAmount { get; set; }
        public decimal dConvertedAmount { get; set; }
        public decimal dRate { get; set; }
        public DateTime dTimestamp { get; set; }
    }
}
