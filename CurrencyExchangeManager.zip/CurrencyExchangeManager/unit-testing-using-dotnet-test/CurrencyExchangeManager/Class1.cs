﻿namespace CurrencyExchangeManager;

public class Class1
{

}
